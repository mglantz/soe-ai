# soe-ai

Experimentation with building a Linux Standard Operating Environment (SOE)
out of specialized AI agents, defined as Claude Code skills. Each skill owns
one configuration domain — its baseline, how to audit for drift, and how to
remediate it — instead of one monolithic hardening script.

## Layout

```
.claude/skills/
  soe/                    # orchestrator: runs all domain skills, aggregates a report
  timesync/                # reference implementation: full audit.sh + remediate.sh
  accounts_policy/         # local account/password policy
  audit_setup/              # auditd configuration and rules
  boot_parameters/          # GRUB/kernel command line baseline
  cron_setup/                # cron/at service and access control
  vm_guest_agent/            # guest agent matching the detected hypervisor
  motd_issue/                 # /etc/motd and /etc/issue* banners
  system_keyboard/            # console keyboard layout
  system_locale/              # system locale (LANG, etc.)
  timezone/                    # system timezone
  troubleshooting_tools/       # baseline troubleshooting package set
  usbguard_setup/               # USBGuard device authorization policy
docs/
  ARCHITECTURE.md            # design rationale, report format, audit/remediate conventions
```

`timesync` is fully built out (`scripts/audit.sh`, `scripts/remediate.sh`,
`scripts/lib/soe_common.sh`) as the template for the rest. The other domain
skills currently define their baseline and a manual audit checklist in
`SKILL.md`; see "Adding a new domain skill" in `docs/ARCHITECTURE.md` for how
to give them scripts.

First-class target platform is RHEL-family Linux (RHEL, CentOS Stream,
Fedora). Every skill defaults to read-only audit mode; remediation is a
separate, explicit step.

See `docs/ARCHITECTURE.md` for the full design.
