---
name: vm_guest_agent
description: Detects the hypervisor a system is running under and audits/remediates the matching guest agent (qemu-guest-agent, open-vm-tools, WALinuxAgent, etc.) as part of the Linux SOE. Use when checking guest-agent presence or state on a virtual machine.
---

# vm_guest_agent

Status: skeleton — baseline and manual checklist defined, no `scripts/`
yet. Port this to `scripts/audit.sh` + `scripts/remediate.sh` following the
`timesync` skill as a template (see `docs/ARCHITECTURE.md`). Unlike the
other domains, this one branches on `systemd-detect-virt` output before
picking a baseline.

## Baseline

- On bare metal (`systemd-detect-virt` returns `none`): no guest agent
  expected; report `[INFO]` and skip.
- On KVM/QEMU (`kvm`): `qemu-guest-agent` installed, `qemu-guest-agent.service`
  enabled and active.
- On VMware (`vmware`): `open-vm-tools` installed, `vmtoolsd.service`
  enabled and active.
- On Hyper-V (`microsoft`): `hyperv-daemons` installed, the relevant
  `hv_*_daemon` services active.
- On a public cloud (AWS/Azure/GCP), prefer the cloud-init/cloud provider's
  own guest agent guidance over the raw hypervisor agent — treat this case
  as `[INFO]` and defer to org policy rather than guessing.

## Manual audit checklist

1. `systemd-detect-virt` — determines which branch below applies.
2. For the matching platform, check package installed + service
   enabled/active exactly as in `timesync`'s pattern for chrony
   (`rpm -q <pkg>`, `systemctl is-enabled <svc>`, `systemctl is-active <svc>`).

## Remediation guidance

Install and enable only the agent matching the detected hypervisor —
installing the wrong one (e.g. `open-vm-tools` on a KVM guest) is wasted
and can mask misconfiguration. If `systemd-detect-virt` is ambiguous or
returns `none` on what the user says is a VM, ask rather than guessing.
