---
name: cron_setup
description: Audits and remediates cron/at service configuration and access control on RHEL-family systems as part of the Linux SOE. Use when checking or hardening crond, cron.allow/cron.deny, or scheduled task permissions.
---

# cron_setup

Status: skeleton — baseline and manual checklist defined, no `scripts/`
yet. Port this to `scripts/audit.sh` + `scripts/remediate.sh` following the
`timesync` skill as a template (see `docs/ARCHITECTURE.md`).

## Baseline

- `cronie` package installed; `crond.service` enabled and active.
- `/etc/cron.allow` exists and lists only approved users; `/etc/cron.deny`
  does not exist (allow-list takes precedence when both are absent/present
  per PAM config — org policy should use an explicit allow-list).
- Same pattern for `/etc/at.allow` / `/etc/at.deny` if `at` is installed.
- `/etc/crontab`, `/etc/cron.d/*`, `/etc/cron.{hourly,daily,weekly,monthly}`
  are not group/world-writable (mode `0644` or stricter for files,
  `0755` or stricter for the directories).
- No cron job in `/etc/cron.d/*` or user crontabs references a
  world-writable script path.

## Manual audit checklist

1. `rpm -q cronie && systemctl is-enabled crond && systemctl is-active crond`
2. `[ -f /etc/cron.allow ] && cat /etc/cron.allow; [ -f /etc/cron.deny ] && echo "cron.deny present"`
3. `find /etc/cron.d /etc/crontab /etc/cron.hourly /etc/cron.daily /etc/cron.weekly /etc/cron.monthly -perm -go+w`
4. For each cron entry, resolve the script path and check
   `stat -c '%a %U' <path>` for world-writability.

## Remediation guidance

Create `/etc/cron.allow` with the approved user list (`chmod 0600`);
remove `/etc/cron.deny` if present. Fix permissions with `chmod`/`chown`
rather than removing jobs — removing a cron job is a behavior change, not a
permissions fix, and needs separate confirmation from the user.
