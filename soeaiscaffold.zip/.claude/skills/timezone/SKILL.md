---
name: timezone
description: Audits and remediates the system timezone on RHEL-family systems as part of the Linux SOE. Use when checking or setting the timezone via timedatectl or /etc/localtime.
---

# timezone

Status: skeleton — baseline and manual checklist defined, no `scripts/`
yet. Port this to `scripts/audit.sh` + `scripts/remediate.sh` following the
`timesync` skill as a template (see `docs/ARCHITECTURE.md`). Closely
related to `timesync` (both affect what time the system reports) but kept
as a separate domain since timezone is a policy choice, not a sync-health
check.

## Baseline

- `/etc/localtime` is a symlink to
  `/usr/share/zoneinfo/<org-standard-timezone>` (org policy: servers should
  generally be `UTC`, but confirm — some orgs standardize on local time for
  operational reasons).
- `timedatectl show --property=Timezone --value` matches the same value.
- `/etc/timezone` (if present — Debian-style, not typically present on
  RHEL) agrees with `/etc/localtime`, to catch split-brain config on mixed
  fleets.

## Manual audit checklist

1. `readlink -f /etc/localtime`
2. `timedatectl show --property=Timezone --value`
3. `[ -f /etc/timezone ] && cat /etc/timezone`

## Remediation guidance

Use `timedatectl set-timezone <Region/City>` rather than manually
re-linking `/etc/localtime` — it keeps `timedatectl`'s view consistent and
is the RHEL-supported way to change it. Confirm the target zone name is a
valid IANA tz identifier (`timedatectl list-timezones`) before setting it.
