---
name: system_keyboard
description: Audits and remediates the system console keyboard layout on RHEL-family systems as part of the Linux SOE. Use when checking or setting the VC/X11 keymap via localectl or /etc/vconsole.conf.
---

# system_keyboard

Status: skeleton — baseline and manual checklist defined, no `scripts/`
yet. Port this to `scripts/audit.sh` + `scripts/remediate.sh` following the
`timesync` skill as a template (see `docs/ARCHITECTURE.md`).

## Baseline

- `/etc/vconsole.conf` sets `KEYMAP=<org-standard>` (e.g. `us`).
- `localectl status` reports the same value for `VC Keymap`.
- If an X11 session is in scope, `localectl status`'s `X11 Layout` also
  matches the org standard (X11 layout can drift independently of the
  console keymap).

## Manual audit checklist

1. `grep '^KEYMAP=' /etc/vconsole.conf`
2. `localectl status`

## Remediation guidance

Use `localectl set-keymap <keymap>` (and `set-x11-keymap <layout>` if
applicable) rather than hand-editing `/etc/vconsole.conf` directly —
`localectl` keeps the console and (if present) X11 config consistent and
regenerates the initramfs keymap where needed.
