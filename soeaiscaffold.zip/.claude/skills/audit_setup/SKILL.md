---
name: audit_setup
description: Audits and remediates the Linux audit subsystem (auditd service state, rules, log rotation and retention) on RHEL-family systems as part of the Linux SOE. Use when checking or configuring auditd/auditctl.
---

# audit_setup

Status: skeleton — baseline and manual checklist defined, no `scripts/`
yet. Port this to `scripts/audit.sh` + `scripts/remediate.sh` following the
`timesync` skill as a template (see `docs/ARCHITECTURE.md`).

## Baseline

- `audit` package installed; `auditd.service` enabled and active.
- `/etc/audit/rules.d/` contains an org-approved rule set (not empty) and
  `augenrules --check` reports the loaded rules match the on-disk rules.
- `/etc/audit/auditd.conf`: `max_log_file_action = rotate`,
  `space_left_action` and `admin_space_left_action` are set to something
  other than the default `ignore` (e.g. `syslog`/`email`/`halt` per org
  policy), and `max_log_file` and `num_logs` reflect the org's retention
  requirement.
- Audit rules are immutable at runtime only if the org requires it
  (`-e 2` as the last rule) — flag as `[INFO]`, not `[FAIL]`, since this is
  org-policy-dependent and irreversible until reboot.

## Manual audit checklist

1. `rpm -q audit && systemctl is-enabled auditd && systemctl is-active auditd`
2. `ls -A /etc/audit/rules.d/`
3. `augenrules --check`
4. `grep -E '^(max_log_file_action|space_left_action|admin_space_left_action|max_log_file|num_logs)' /etc/audit/auditd.conf`
5. `auditctl -s | grep -E 'enabled|rules'`

## Remediation guidance

Install/enable via `dnf install -y audit && systemctl enable --now auditd`.
Add rules under `/etc/audit/rules.d/*.rules` and run `augenrules --load`
rather than editing `/etc/audit/audit.rules` directly (it's generated).
Setting `-e 2` (immutable) requires a reboot to undo — call this out and
get explicit confirmation before applying it.
