---
name: usbguard_setup
description: Audits and remediates USBGuard device authorization policy on RHEL-family systems as part of the Linux SOE. Use when checking or configuring USB device allow/block policy via usbguard.
---

# usbguard_setup

Status: skeleton — baseline and manual checklist defined, no `scripts/`
yet. Port this to `scripts/audit.sh` + `scripts/remediate.sh` following the
`timesync` skill as a template (see `docs/ARCHITECTURE.md`).

## Baseline

- `usbguard` package installed; `usbguard.service` enabled and active.
- `/etc/usbguard/usbguard-daemon.conf` sets `ImplicitPolicyTarget=block`
  (default-deny, org policy may vary — confirm before assuming).
- `/etc/usbguard/rules.conf` is non-empty and exists (mode `0600`, owned by
  `root:root` — it can encode which specific devices are trusted).
- Currently-connected devices at audit time are all in an `allow` state per
  `usbguard list-devices`, i.e. nothing is unexpectedly blocked that
  shouldn't be, and nothing unexpected is allowed that shouldn't be — this
  needs an org-provided expected-device list to check meaningfully, so
  without one, just report the current device list as `[INFO]` for human
  review.

## Manual audit checklist

1. `rpm -q usbguard && systemctl is-enabled usbguard && systemctl is-active usbguard`
2. `grep '^ImplicitPolicyTarget' /etc/usbguard/usbguard-daemon.conf`
3. `stat -c '%a %U:%G' /etc/usbguard/rules.conf`
4. `usbguard list-devices`

## Remediation guidance

Installing/enabling usbguard on a system with USB keyboards/mice attached
can lock out physical console access if the default policy is `block` and
no rule allows HID devices — **this is a high blast-radius change**.
Before enabling on a system with only physical (non-remote) access, either
generate an initial allow-list from currently connected devices
(`usbguard generate-policy > /etc/usbguard/rules.conf`) first, or get
explicit confirmation from the user that they understand the risk and have
another access path (e.g. remote console/iDRAC/iLO) if it goes wrong.
