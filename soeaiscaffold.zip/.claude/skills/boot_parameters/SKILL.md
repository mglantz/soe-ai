---
name: boot_parameters
description: Audits and remediates GRUB/kernel boot command-line parameters on RHEL-family systems as part of the Linux SOE. Use when checking or hardening kernel boot parameters, GRUB config, or secure boot state.
---

# boot_parameters

Status: skeleton — baseline and manual checklist defined, no `scripts/`
yet. Port this to `scripts/audit.sh` + `scripts/remediate.sh` following the
`timesync` skill as a template (see `docs/ARCHITECTURE.md`).

## Baseline

- `audit=1` present on the kernel command line (feeds auditd from early
  boot; pairs with `audit_setup`).
- SELinux not disabled at boot (no `selinux=0` in `GRUB_CMDLINE_LINUX`);
  enforcing mode is checked separately, this only guards against the
  boot-time override.
- No debugging/insecure overrides present unless explicitly approved:
  `mitigations=off`, `nopti`, `nospectre_v2`, `init=/bin/bash`.
- `/etc/default/grub` and the generated config
  (`/boot/grub2/grub.cfg` or `/boot/efi/EFI/<distro>/grub.cfg` on UEFI) are
  in sync — i.e. a `grub2-mkconfig` was run after the last edit.
- `/boot/grub2/grub.cfg` (or the UEFI equivalent) is not world-readable if
  it contains a password hash (mode `0600` in that case).

## Manual audit checklist

1. `cat /proc/cmdline`
2. `grep GRUB_CMDLINE_LINUX /etc/default/grub`
3. `grep -oE 'mitigations=off|nopti|nospectre_v2|init=/bin/(ba)?sh' /proc/cmdline`
4. Compare `GRUB_CMDLINE_LINUX` in `/etc/default/grub` against what's
   actually baked into the generated `grub.cfg` for the current kernel entry.
5. `stat -c '%a' /boot/grub2/grub.cfg` (or UEFI path)

## Remediation guidance

Edit `/etc/default/grub`, then regenerate with
`grub2-mkconfig -o /boot/grub2/grub.cfg` (BIOS) or the UEFI-specific output
path — get this path right for the host, a wrong path silently does
nothing. Boot parameter changes only take effect on next boot; tell the
user a reboot is required and do not reboot the host without explicit
confirmation.
