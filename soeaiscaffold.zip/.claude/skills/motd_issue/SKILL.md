---
name: motd_issue
description: Audits and remediates /etc/motd and /etc/issue* banner files on RHEL-family systems as part of the Linux SOE. Use when checking or standardizing login banners or checking for information disclosure in pre-auth banners.
---

# motd_issue

Status: skeleton — baseline and manual checklist defined, no `scripts/`
yet. Port this to `scripts/audit.sh` + `scripts/remediate.sh` following the
`timesync` skill as a template (see `docs/ARCHITECTURE.md`).

## Baseline

- `/etc/motd` matches the org's approved post-login banner text exactly
  (byte-for-byte, or via a checksum against the approved template).
- `/etc/issue` (local console, pre-auth) and `/etc/issue.net` (remote,
  pre-auth via sshd) contain the org's approved legal/warning banner and do
  **not** contain `\v`, `\r`, `\m`, `\s` escape sequences that would leak OS
  name/version/kernel to an unauthenticated user.
- `sshd_config` has `Banner /etc/issue.net` set if the org requires the
  pre-auth SSH banner (this file is separate from PAM's local-login
  `/etc/issue`).
- File permissions `0644`, owned by `root:root`.

## Manual audit checklist

1. `diff /etc/motd <(cat path/to/approved-motd-template)`
2. `grep -E '\\\\[vrms]' /etc/issue /etc/issue.net`
3. `grep -i '^Banner' /etc/ssh/sshd_config /etc/ssh/sshd_config.d/*.conf 2>/dev/null`
4. `stat -c '%a %U:%G' /etc/motd /etc/issue /etc/issue.net`

## Remediation guidance

Overwrite the three files from the org's approved templates; fix
permissions with `chmod 0644` / `chown root:root`. If `Banner` isn't set in
sshd_config, add it and run `sshd -t` to validate syntax before reloading
`sshd` — an invalid sshd_config can lock out remote access, so validate
before reload, never restart blindly.
