---
name: troubleshooting_tools
description: Audits and remediates the baseline set of troubleshooting/diagnostic packages installed on RHEL-family systems as part of the Linux SOE. Use when checking whether standard diagnostic tools (sos, tcpdump, strace, lsof, bind-utils) are present, or flagging unapproved extras.
---

# troubleshooting_tools

Status: skeleton — baseline and manual checklist defined, no `scripts/`
yet. Port this to `scripts/audit.sh` + `scripts/remediate.sh` following the
`timesync` skill as a template (see `docs/ARCHITECTURE.md`).

## Baseline

Org-approved baseline package set (adjust to the org's actual list before
relying on this):

- `sos` (sosreport for support-bundle collection)
- `tcpdump`
- `strace`
- `lsof`
- `bind-utils` (`dig`, `nslookup`, `host`)
- `nmap-ncat`
- `iotop`

This is a two-sided check: packages in the list that are **missing** are
drift; packages **outside** the approved list that look like troubleshooting
tools installed ad hoc (e.g. `wireshark`, `nmap`) should be flagged as
`[INFO]` for the user to review, not auto-removed — removing packages a
human installed for a reason is a judgment call, not an automatable fix.

## Manual audit checklist

1. For each package in the baseline list: `rpm -q <pkg>`.
2. `dnf history userinstalled | grep -Ev '<baseline-package-regex>'` to spot
   packages installed outside the baseline (heuristic, not exhaustive).

## Remediation guidance

`dnf install -y <missing-packages>` for anything missing from the baseline.
Never `dnf remove` a package flagged as "outside baseline" without the user
confirming it's actually unwanted — it may be legitimately needed by an
application on that host.
