---
name: accounts_policy
description: Audits and remediates local account and password policy (aging, complexity, UID ranges, empty/locked passwords, sudoers hygiene) on RHEL-family systems as part of the Linux SOE. Use when checking or hardening local user account policy.
---

# accounts_policy

Status: skeleton — baseline and manual checklist defined, no `scripts/`
yet. Port this to `scripts/audit.sh` + `scripts/remediate.sh` following the
`timesync` skill as a template (see `docs/ARCHITECTURE.md`).

## Baseline

- Password aging in `/etc/login.defs`: `PASS_MAX_DAYS <= 90`,
  `PASS_MIN_DAYS >= 1`, `PASS_WARN_AGE >= 7`.
- Password quality enforced via `/etc/security/pwquality.conf`
  (`minlen`, `dcredit`, `ucredit`, `lcredit`, `ocredit` set per org policy).
- No accounts with empty passwords (`passwd -S` shows no `NP`, and
  `/etc/shadow` has no empty second field).
- `UID_MIN`/`UID_MAX` in `/etc/login.defs` match the org's reserved system
  UID range; no unexpected human accounts with UID below `UID_MIN`.
- No duplicate UIDs/GIDs (`awk -F: '{print $3}' /etc/passwd | sort | uniq -d`
  is empty).
- Inactive/stale local accounts are locked (`lastlog`/`chage -l`) rather than
  left enabled.
- `/etc/sudoers` and `/etc/sudoers.d/*` contain no `NOPASSWD:ALL` entries
  outside an explicitly approved list, and are mode `0440`.

## Manual audit checklist

1. `grep -E '^(PASS_MAX_DAYS|PASS_MIN_DAYS|PASS_WARN_AGE)' /etc/login.defs`
2. `cat /etc/security/pwquality.conf`
3. `awk -F: '($2==""){print $1}' /etc/shadow`
4. `grep -E '^(UID_MIN|UID_MAX)' /etc/login.defs`
5. `awk -F: '{print $3}' /etc/passwd | sort | uniq -d`
6. `grep -rn 'NOPASSWD:ALL' /etc/sudoers /etc/sudoers.d/ 2>/dev/null`
7. `find /etc/sudoers /etc/sudoers.d -type f ! -perm 0440`

Report each check's pass/fail using the `[PASS]`/`[FAIL]`/`[INFO]` format
from `docs/ARCHITECTURE.md`.

## Remediation guidance

Change values with `authselect`/`chage`/direct edits to `/etc/login.defs`
and `pwquality.conf`; lock stale accounts with `usermod -L`; never delete
an account as "remediation" without explicit user confirmation — locking is
reversible, deletion is not. Fix sudoers file permissions with
`chmod 0440`, and always edit sudoers via `visudo -f <file>` to avoid
syntax errors that lock out sudo.
