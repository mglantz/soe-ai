---
name: timesync
description: Audits and remediates time synchronization (chronyd) on RHEL-family systems as part of the Linux Standard Operating Environment. Use when checking, configuring, or fixing NTP/chrony time sync, clock drift, or "system clock not synchronized" issues.
---

# timesync

Reference implementation for a domain skill in the SOE. Other domain skills
in this repo follow this same pattern — see `docs/ARCHITECTURE.md` for the
shared conventions (report format, audit vs. remediate, exit codes).

## Baseline

On a compliant RHEL-family host:

- `chrony` package is installed.
- `chronyd.service` is enabled and active.
- `/etc/chrony.conf` defines at least one `server` or `pool` line.
- The system clock is actually synchronized (not just "chronyd is running").

## What to do

**To audit** (default — read-only, safe to run any time):

```
.claude/skills/timesync/scripts/audit.sh
```

Report the `[PASS]`/`[FAIL]` lines and the summary to the user in plain
language. Exit code `0` means compliant, `1` means drift was found.

**To remediate** (modifies the system — only run after the user explicitly
asks for the fix to be applied, not just the audit): first summarize what
`remediate.sh` is about to change (install chrony if missing, append a
default pool if none is configured, enable+start chronyd), then run:

```
.claude/skills/timesync/scripts/remediate.sh
```

It re-runs the audit at the end so the reported result reflects actual
system state, not assumed success.

## Notes

- If the host is not RHEL-family (`soe_is_rhel_family` in
  `scripts/lib/soe_common.sh` returns false), the audit still runs but flags
  this with `[INFO]` — chrony config paths and package names may differ on
  other distros (e.g. Debian uses `/etc/chrony/chrony.conf`).
- The default pool used in remediation (`2.rhel.pool.ntp.org`) is a
  placeholder; an organization should point this at its own internal NTP
  servers if it has them, by editing `DEFAULT_POOL` in `remediate.sh`.
