---
name: system_locale
description: Audits and remediates the system locale (LANG and related settings) on RHEL-family systems as part of the Linux SOE. Use when checking or setting /etc/locale.conf or resolving locale warnings.
---

# system_locale

Status: skeleton — baseline and manual checklist defined, no `scripts/`
yet. Port this to `scripts/audit.sh` + `scripts/remediate.sh` following the
`timesync` skill as a template (see `docs/ARCHITECTURE.md`).

## Baseline

- `/etc/locale.conf` sets `LANG=<org-standard>` (e.g. `en_US.UTF-8`).
- `localectl status`'s `System Locale` matches the same value.
- The configured locale is actually installed/generated
  (`localectl list-locales` includes it) — a `LANG` pointing at a locale
  that isn't installed causes `perl: warning: Setting locale failed`-style
  errors system-wide.
- No conflicting `LANG`/`LC_*` overrides in `/etc/environment` or
  `/etc/profile.d/*.sh` that disagree with `/etc/locale.conf`.

## Manual audit checklist

1. `grep '^LANG=' /etc/locale.conf`
2. `localectl status`
3. `localectl list-locales | grep -x "<org-standard-locale>"`
4. `grep -RE '^(LANG|LC_[A-Z]+)=' /etc/environment /etc/profile.d/*.sh 2>/dev/null`

## Remediation guidance

Install the locale if missing (`localedef` or `dnf reinstall glibc-langpack-<lang>`
on RHEL/Fedora), then set it with `localectl set-locale LANG=<value>` rather
than hand-editing `/etc/locale.conf`. Remove conflicting overrides only
after confirming with the user they're not there intentionally for a
specific application.
