---
name: soe
description: Orchestrates all Linux Standard Operating Environment domain skills to audit or remediate a RHEL-family host, and aggregates their results into one compliance report. Use when asked to check, audit, or bring a system into compliance with "the SOE" or "the standard operating environment" as a whole, rather than a single domain.
---

# soe

Top-level orchestrator for the domain skills under `.claude/skills/`. Each
domain owns one part of the SOE baseline; this skill runs them and rolls the
results up. See `docs/ARCHITECTURE.md` for the shared conventions these
skills follow (report format, audit vs. remediate, exit codes).

## Domain skills

| Skill | Domain | Scripts |
|---|---|---|
| `accounts_policy` | Local account/password policy | not yet implemented |
| `audit_setup` | auditd configuration and rules | not yet implemented |
| `boot_parameters` | GRUB/kernel command line baseline | not yet implemented |
| `cron_setup` | cron/at service and access control | not yet implemented |
| `vm_guest_agent` | Guest agent for the detected hypervisor | not yet implemented |
| `motd_issue` | `/etc/motd` and `/etc/issue*` banners | not yet implemented |
| `system_keyboard` | Console/system keyboard layout | not yet implemented |
| `system_locale` | System locale (`LANG`, etc.) | not yet implemented |
| `timesync` | NTP/chrony time synchronization | `scripts/audit.sh`, `scripts/remediate.sh` (reference implementation) |
| `timezone` | System timezone | not yet implemented |
| `troubleshooting_tools` | Baseline troubleshooting package set | not yet implemented |
| `usbguard_setup` | USBGuard device authorization policy | not yet implemented |

## What to do

**To audit the whole SOE**: for each domain skill that has a
`scripts/audit.sh`, run it and collect its `[PASS]`/`[FAIL]` lines and exit
code. For domains without scripts yet, open that skill's `SKILL.md` and walk
its manual audit checklist instead, and say clearly in the report that this
domain was checked manually / has no automated script yet.

Aggregate into one report, e.g.:

```
== SOE compliance report ==
timesync             : 4 pass, 0 fail
usbguard_setup        : manual check — see .claude/skills/usbguard_setup/SKILL.md
...
------------------------------
TOTAL (automated only): 4 pass, 0 fail across 1 domain with scripts
```

**To remediate the whole SOE**: never do this without the user explicitly
asking to apply fixes across all domains (this touches auth, boot config,
and device policy — high blast radius). Prefer remediating one domain at a
time with the user's confirmation, per `docs/ARCHITECTURE.md`. If the user
does ask for a full remediation pass, list every domain and the specific
change each `remediate.sh` would make *before* running any of them.

## Adding a domain

Follow "Adding a new domain skill" in `docs/ARCHITECTURE.md`, then add a row
to the table above.
