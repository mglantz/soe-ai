# Architecture

soe-ai defines a Linux Standard Operating Environment (SOE) as a set of
independent Claude Code **skills**, one per configuration domain. Each skill
owns the baseline, audit logic, and remediation logic for exactly one part of
the system (accounts, time sync, USB policy, etc.). A top-level `soe`
orchestrator skill runs the domain skills and rolls their results into a
single compliance report.

## Why skills, not a monolithic script

- Each domain's knowledge (which files, which commands, which RHEL tooling)
  stays isolated and independently testable.
- Skills are composable: run one domain skill ad hoc ("check timesync on this
  box") or run all of them via the `soe` orchestrator.
- New domains are added by adding a new skill directory — no changes to
  existing skills required.

## Target platform

First-class support targets RHEL-family systems (RHEL, CentOS Stream,
Fedora) using their native tooling: `dnf`, `systemctl`, `chronyd`,
`authselect`, `auditd`, `usbguard`, `firewalld`. Skills that assume RHEL-family
tooling should detect this and say so rather than silently doing the wrong
thing on other distros.

## Layout

```
.claude/skills/
  soe/                    # orchestrator: runs all domain skills, aggregates report
  <domain>/
    SKILL.md              # baseline definition + when/how Claude should act
    scripts/
      audit.sh            # read-only: reports drift, never modifies the system
      remediate.sh         # applies fixes; only run with explicit user approval
      lib/soe_common.sh   # shared shell helpers (report format, root check, distro detect)
```

Not every domain skill has scripts yet — `timesync` is the reference
implementation. Skills without scripts still define their baseline and
manual audit/remediation steps in `SKILL.md`; port them to scripts using
`timesync/scripts/` as the template.

## Audit vs. remediate

Every domain skill supports two modes, mirroring how CIS/OpenSCAP tooling
works:

- **Audit (default)**: read-only. Checks live system state against the
  baseline and reports pass/fail per check. Never modifies the system.
- **Remediate**: applies fixes to bring the system into compliance. Only
  run when the user has explicitly asked for changes to be made — per the
  general rule on risky/hard-to-reverse actions, Claude should not run a
  `remediate.sh` unprompted, and should summarize what it's about to change
  before running it.

`remediate.sh` always re-runs `audit.sh` at the end so the reported end
state reflects reality rather than assumed success.

## Report format

Audit and remediate scripts print one line per check, then a summary line,
using `scripts/lib/soe_common.sh` helpers:

```
[PASS] chronyd is enabled
[FAIL] no NTP server/pool configured in /etc/chrony.conf
[INFO] Non-RHEL system detected; results may not apply
[FIXED] added default pool '2.rhel.pool.ntp.org iburst' to /etc/chrony.conf

--- timesync audit: 3 pass, 1 fail ---
```

`audit.sh` exits `0` when there are zero `[FAIL]` lines and `1` otherwise, so
the `soe` orchestrator (or CI) can use exit codes to gate on compliance.

## Adding a new domain skill

1. `mkdir -p .claude/skills/<domain>/scripts/lib`
2. Copy `timesync/scripts/lib/soe_common.sh` in unchanged.
3. Write `SKILL.md`: baseline, audit checklist, remediation steps.
4. Write `scripts/audit.sh` and `scripts/remediate.sh` following the
   `timesync` pattern.
5. Add the domain to the list in `.claude/skills/soe/SKILL.md`.
