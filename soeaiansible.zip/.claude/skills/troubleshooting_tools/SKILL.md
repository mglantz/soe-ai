---
name: troubleshooting_tools
description: Maintains the ansible/roles/troubleshooting_tools Ansible role that audits and remediates the baseline set of troubleshooting/diagnostic packages installed on RHEL-family systems as part of the Linux SOE. Use when checking whether standard diagnostic tools (sos, tcpdump, strace, lsof, bind-utils) are present.
---

# troubleshooting_tools

Maintains `ansible/roles/troubleshooting_tools/`. See
`docs/ARCHITECTURE.md` for the shared conventions.

## Baseline

Encoded in `ansible/roles/troubleshooting_tools/defaults/main.yml`
(`soe_troubleshooting_packages`, adjust to the org's actual list before
relying on this): `sos`, `tcpdump`, `strace`, `lsof`, `bind-utils`,
`nmap-ncat`, `iotop`.

## What to do

**Audit**: `ansible-playbook ansible/site.yml --tags troubleshooting_tools --check --diff`

**Remediate**: same command without `--check`, after explicit user
approval — this only *installs* missing baseline packages, it never
removes anything (see Notes).

## Notes

- This is a one-directional check: packages **missing** from the baseline
  are installed. Packages **outside** the baseline (installed ad hoc, e.g.
  `wireshark`) are listed via `dnf history userinstalled` for the user to
  review, but this role never runs `dnf remove` on them — removing a
  package a human installed for a reason is a judgment call, not something
  to automate.
